package com.example.Member_CRUD.controller;

import com.example.Member_CRUD.domain.Member;
import com.example.Member_CRUD.repository.*;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/members")
public class MemberController {

	@Autowired
	private MemberRepository memberRepository;
	
	//CRUD 요청과 응답
	//Create (회원등록)
	@PostMapping
	public Member create(@RequestBody Member member) {
		return memberRepository.save(member);
	}
	
	//Read (모든회원조회)
	@GetMapping
	public List<Member> readAll(){
		return memberRepository.findAll();
	}
	
	//Read (특정 회원조회)
	@GetMapping("/{id}")
	public Member read(@PathVariable Long id){
		return memberRepository.findById(id).orElse(null);
	}
	
	//Update (특정 회원 수정)
	@PutMapping("/{id}")
	public Member update(@PathVariable Long id, @RequestBody Member member){
		Member existing = memberRepository.findById(id).orElse(null);
		
		if(existing != null) {
			//새로운 값 변경
			existing.setName(member.getName());
			existing.setEmail(member.getEmail());
			existing.setPassword(member.getPassword());
			return memberRepository.save(existing);
		} 
		return null;
	}
	
	//Delete (특정 회원 삭제)
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Long id){
		memberRepository.deleteById(id);
	}
	
}
