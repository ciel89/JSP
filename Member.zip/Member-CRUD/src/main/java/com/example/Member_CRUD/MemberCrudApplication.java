package com.example.Member_CRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemberCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemberCrudApplication.class, args);
	}

}
