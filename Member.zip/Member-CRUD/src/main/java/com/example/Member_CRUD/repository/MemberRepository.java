package com.example.Member_CRUD.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Member_CRUD.domain.Member;

//엔티티 임포트, PK의 데이터형
public interface MemberRepository extends JpaRepository<Member,Long>{
	
}
